# This program adds two variables

var1 = 3
var3 = 5

print (var1 + var3)